public class Suite extends Room{

    public Suite() {
        super("Suite", 650, 80, true);

    }
};
