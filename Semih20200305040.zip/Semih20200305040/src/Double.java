public class Double extends Room{

    public Double() {
        super("Double", 180, 30, false);

    }
};