public class Family extends Room{

    public Family() {
        super("Family", 400, 50, false);

    }
};