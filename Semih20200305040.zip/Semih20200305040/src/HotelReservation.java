import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class HotelReservation {

    public static void main(String[] args) {
        int option;
        LinkedList<Calculable> calculableList = new LinkedList<Calculable>();
        Scanner input = new Scanner(System.in);
        do {
            for (MenuOptions opt : MenuOptions.values()) {
                System.out.println(opt.getOption());
            }
            option = input.nextInt();
            switch (option) {
                case 12:
                    System.out.println("Exiting, Goodbye!");
                    break;
                case 1:
                    System.out.println(Room.RoomInfo());
                    Reservation reservation = new Reservation();
                    calculableList.add(reservation);
                    Reservation.totalNumOfReservations++;
                    System.out.printf("\nReservation ID: %d is created!\n",Reservation.GetCountReservations());
                    reservation.setCustomerID(Reservation.GetCountReservations());
                    System.out.println();
                    break;
                case 2:
                    for(int i=0; i<Reservation.GetCountReservations(); i++) {
                        ((Reservation) calculableList.get(i)).displayInfo();
                    }
                    System.out.println();
                    break;
                case 3:
                    System.out.print("Type a city name for a reservation search: ");
                    input.nextLine();
                    String cityname = input.nextLine();
                    List <Reservation> list = new ArrayList<Reservation>();
                    for (Calculable item : calculableList) {
                        if(item instanceof Reservation) {
                            list.add((Reservation)item);
                        }
                    }
                    Iterator <Reservation> iterator = list.iterator();
                    while(iterator.hasNext()){
                        String hotelName = ((Reservation) iterator.next()).getHotelName();
                        if(hotelName.contains(cityname)){
                            System.out.println(hotelName);
                        }
                    }
                    System.out.println();
                    break;
                case 4:
                    System.out.println("\n"+"Please select one of the extra services from below:\n"
                            + "1. Laundry Service\n"
                            + "2. Spa Service");
                    int opt = input.nextInt();
                    if(opt == 1) {
                        Laundry laundry = new Laundry();
                        calculableList.add(laundry);
                        System.out.println("Type the reservation ID to credit this service: ");
                        int id = input.nextInt();
                        if(id <= Reservation.GetCountReservations())
                            laundry.setCustomerID(id);
                        else {
                            while(!(id <= Reservation.GetCountReservations())){
                                System.out.println("Wrong process!!!");
                                System.out.print("Try Again: ");
                                id = input.nextInt();
                                laundry.setCustomerID(id);
                            }
                        }
                        System.out.println("How many pieces of clothing: ");
                        laundry.setClothingPieces(input.nextInt());
                        System.out.println();
                    }
                    else if(opt == 2) {
                        Spa spa = new Spa();
                        calculableList.add(spa);
                        System.out.println("Type the reservation ID to credit this service:");
                        int id = input.nextInt();
                        if(id <= Reservation.GetCountReservations())
                            spa.setCustomerID(id);
                        else {
                            while(!(id <= Reservation.GetCountReservations())){
                                System.out.println("Wrong process!!!");
                                System.out.print("Try Again: ");
                                id = input.nextInt();
                                spa.setCustomerID(id);
                            }
                        }
                        System.out.println("How many days?");
                        spa.setDays(input.nextInt());
                        System.out.println();
                    }
                    break;
                case 5:
                    System.out.println();
                    for (Calculable serv : calculableList) {
                        if(serv instanceof Reservation) {
                            System.out.printf(((Services) serv).getServiceType() + " for ID: %d: %.2f \n",((Services) serv).getCustomerID(),((Services) serv).calculateService());
                        }
                        if(serv instanceof Spa) {
                            System.out.printf(((Services) serv).getServiceType() + " for ID: %d: %.2f \n",((Services) serv).getCustomerID(),((Services) serv).calculateService());
                        }
                        if (serv instanceof Laundry) {
                            System.out.printf(((Services) serv).getServiceType() + " for ID: %d: %.2f \n",((Services) serv).getCustomerID(),((Services) serv).calculateService());
                        }
                    }
                    System.out.println();
                    break;
                case 6:
                    System.out.println();
                    List<Services> servs = new ArrayList<Services>();
                    for (Calculable service : calculableList) {
                        if(service instanceof Services){
                            servs.add((Services)service);
                        }
                    }
                    double total = 0;
                    for(int i=0; i<Reservation.GetCountReservations(); i++) {
                        for(int j=0; j<servs.size(); j++) {
                            if((servs.get(j)).getCustomerID() == (servs.get(i)).getCustomerID())
                                total += (servs.get(j)).calculateService();
                        }
                        System.out.printf("The total cost of all services of the reservation with ID: %d is %.2f\n"
                                ,(servs.get(i)).getCustomerID(),total);
                        total = 0;
                    }
                    System.out.println();
                    break;
                case 7:
                    Employees employees = new Employees();
                    calculableList.add(employees);
                    break;
                case 8:
                    Bills bills = new Bills();
                    calculableList.add(bills);
                    break;
                case 9:
                    System.out.println("\nEnter Month:");
                    input.nextLine();
                    String month = input.nextLine();
                    double income = 0,expenseEmployee = 0,expenseBills = 0;
                    List<Integer> Rooms = new ArrayList<Integer>();
                    for (Calculable serv : calculableList) {
                        if(serv instanceof Reservation) {
                            if(((Reservation) serv).getReservationMonth().equals(month)) {
                                System.out.printf("For reservation ID: %d, Service type: %s, Service Cost: %.2f \n",
                                        ((Services)serv).getCustomerID(),((Services)serv).getServiceType(),((Services)serv).getCost());
                                income += ((Services)serv).calculateService();
                                Rooms.add(((Services)serv).getCustomerID());
                            }
                        }
                        else if(serv instanceof Laundry) {
                            for (int i = 0; i<Rooms.size(); i++) {
                                if(((Laundry)serv).getCustomerID() == Rooms.get(i)){
                                    System.out.printf("For reservation ID: %d, Service type: %s, Service Cost: %.2f \n",
                                            ((Services)serv).getCustomerID(),((Services)serv).getServiceType(),((Services)serv).getCost() );
                                    income += ((Services)serv).getCost();
                                }
                            }
                        }
                        else if(serv instanceof Spa) {
                            for (int i = 0; i<Rooms.size(); i++) {
                                if(((Spa)serv).getCustomerID() == Rooms.get(i)){
                                    System.out.printf("For reservation ID: %d, Service type: %s, Service Cost: %.2f \n",
                                            ((Services)serv).getCustomerID(),((Services)serv).getServiceType(),((Services)serv).getCost() );
                                    income += ((Services)serv).getCost();
                                }
                            }
                        }
                    }
                    System.out.printf("Total monthly income : %.2f \n",income);
                    for (Calculable serv : calculableList) {
                        if(serv instanceof Bills) {
                            if(((Bills) serv).getMonth().equals(month)){
                                expenseBills += serv.getCost();
                            }
                        }
                        if(serv instanceof Employees) {
                            expenseEmployee += serv.getCost();
                        }
                    }
                    double account = income - (expenseBills + expenseEmployee );
                    System.out.printf("Total monthly bills due: %.2f \n",expenseBills);
                    System.out.printf("Total monthly employee cost: %.2f \n",expenseEmployee);
                    System.out.printf("End of month balance: %.2f \n",(account));
                    System.out.println();
                    break;

                case 10:
                    System.out.println();
                    List<Services> services = new ArrayList<Services>();
                    for (Calculable item : calculableList) {
                        if(item instanceof Services) {
                            services.add((Services) item);
                        }
                    }
                    Collections.sort(services, new CostComparator());
                    Collections.reverse(services);
                    for (Services item : services) {
                        if(item instanceof Reservation) {
                            System.out.printf("Customer ID: %d, Service Type: %s, Cost: %.2f\n",
                                    item.getCustomerID(),item.getServiceType(),item.calculateService());
                        }
                        else item.displayServiceInfo();
                    }
                    System.out.println();
                    break;

                case 11:
                    System.out.println();
                    List<Reservation> reservations = new ArrayList<Reservation>();
                    for (Calculable item : calculableList) {
                        if(item instanceof Reservation) {
                            reservations.add((Reservation) item);
                        }
                    }
                    Collections.sort(reservations);


                    for (Reservation item : reservations) {
                        item.displayServiceInfo();
                    }
                    System.out.println();
                    break;

                default:
                    System.err.println("Wrong option...");
                    break;
            }
        }while (option != 12);
        input.close();
    }
};
