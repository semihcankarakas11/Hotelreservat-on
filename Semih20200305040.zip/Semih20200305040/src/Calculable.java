public interface Calculable {
    double getCost();
}

