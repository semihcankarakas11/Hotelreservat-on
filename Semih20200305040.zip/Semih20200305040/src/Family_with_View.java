public class Family_with_View extends Room{

    public Family_with_View() {
        super("Family with View", 450, 50, true);

    }
};
