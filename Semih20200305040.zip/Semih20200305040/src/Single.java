public class Single extends Room{

    public Single() {
        super("Single", 100, 15, false);

    }
};
