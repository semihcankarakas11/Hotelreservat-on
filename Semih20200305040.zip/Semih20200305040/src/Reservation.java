import java.util.Scanner;
public class Reservation extends Services implements Comparable<Reservation>{

    public Room room;
    protected String hotelName;
    private String reservationMonth;
    private int reservationStart;
    private int reservationEnd ;
    private int dailyCost;
    Scanner input = new Scanner(System.in);
    static int totalNumOfReservations = 0;

    public Reservation(){

        System.out.print("Hotel Name: ");
        String hotelName = input.nextLine();
        setHotelName(hotelName);

        System.out.print("Room Type: ");
        String roomType = input.nextLine();
        if(roomType.equals("Single")) {
            Single room1 = new Single();
            this.room = room1;
        }
        else if(roomType.equals("Double")) {
            Double room2 = new Double();
            this.room = room2;
        }
        else if(roomType.equals("Club")) {
            Club room3 = new Club();
            this.room = room3;
        }
        else if(roomType.equals("Family")) {
            Family room4 = new Family();
            this.room = room4;
        }
        else if(roomType.equals("Family with View")) {
            Family_with_View room5 = new Family_with_View();
            this.room = room5;
        }
        else if(roomType.equals("Suite")) {
            Suite room6 = new Suite();
            this.room = room6;
        }

        System.out.print("Reservation Month: ");
        String ReservationMonth = input.nextLine();
        setReservationMonth(ReservationMonth);

        System.out.print("Reservation Start: ");
        int ReservationStart = input.nextInt();
        setReservationStart(ReservationStart);

        System.out.print("Reservation End: ");
        int ReservationEnd = input.nextInt();
        setReservationEnd(ReservationEnd);

    }
    public int calculateTotalPrice(String month){
        String[] summerMonth = {"June", "July", "August"};
        for(int i=0; i<3; i++) {
            if(summerMonth[i].equals(month)) {
                return 2 * (room.getDailyCost() * (getReservationEnd()-getReservationStart()));
            }
        }
        return (room.getDailyCost() * (getReservationEnd()-getReservationStart()));
    }

    public int calculateTotalPrice() {
        return getDailyCost() * (getReservationEnd()-getReservationStart());

    }

    public void displayInfo() {
        System.out.println("\nReservation for a " + room.getRoomType() + " room in " + getHotelName() + " starts on " + getReservationMonth() +
                " " +  getReservationStart() + " and ends on " + getReservationMonth() + " " + getReservationEnd()
                + " Reservation has a total cost of " + "$"+ calculateTotalPrice(getReservationMonth()));

    }
    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }
    public String getHotelName() {
        return hotelName;
    }
    public void setReservationMonth(String reservationMonth) {
        if(CheckMonth(reservationMonth)) {
            this.reservationMonth = reservationMonth;
        }
        else {
            String newReservationMonth = reservationMonth;
            while(!(CheckMonth(newReservationMonth))) {
                System.out.print("Wrong input try again(You must be begin with capital letter): ");
                newReservationMonth = input.nextLine();
                this.reservationMonth = newReservationMonth;
            }
        }
    }
    public String getReservationMonth() {
        return reservationMonth;
    }
    public void setReservationStart(int reservationStart) {
        if(reservationStart<31 && reservationStart>0) {
            this.reservationStart = reservationStart;
        }
        else {
            int newReservationStart = reservationStart;
            while(!(newReservationStart<31 && newReservationStart>0)) {
                System.out.println("Wrong process!!!");
                System.out.print("Try Again: ");
                newReservationStart = input.nextInt();
                this.reservationStart = newReservationStart;
            }
        }
    }
    public int getReservationStart() {
        return reservationStart;
    }
    public void setReservationEnd(int reservationEnd) {
        if(reservationEnd<31 && reservationEnd>reservationStart) {
            this.reservationEnd = reservationEnd;
        }
        else {
            int newReservationEnd = reservationEnd;
            while(!(newReservationEnd<31 && newReservationEnd>reservationStart)) {
                System.out.println("Wrong process!!!");
                System.out.print("Try Again: ");
                newReservationEnd = input.nextInt();
                this.reservationEnd = newReservationEnd;
            }
        }
    }
    public int getReservationEnd() {
        return reservationEnd;
    }
    public void setDailyCost(int dailyCost) {
        this.dailyCost = dailyCost;
    }
    public int getDailyCost() {
        return dailyCost;
    }
    public static int GetCountReservations() {
        return totalNumOfReservations;
    }
    public static boolean CheckMonth(String input) {
        String[] Month = {"January","February","March","April","May","June","July","August","September","November","December"};
        for (String month : Month) {
            if(input.equals(month))
                return true;
        }
        return false;
    }

    @Override
    public void displayServiceInfo() {
        System.out.printf("Hotel Name: %s, Customer ID: %d, Service Type: %s, Cost: %.2f\n",
                getHotelName(), getCustomerID(), getServiceType(), calculateService());
    }

    @Override
    public String getServiceType() {

        return "Room booking";
    }

    @Override
    public double calculateService() {
        return calculateTotalPrice(getReservationMonth());
    }


    public int compareTo(Reservation o) {
        return this.getHotelName().compareTo(o.getHotelName());
    }

    public double getCost() {

        return calculateService();
    }

}
