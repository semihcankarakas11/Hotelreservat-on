public class Club extends Room{

    public Club() {
        super("Club", 250, 45, true);

    }
};

