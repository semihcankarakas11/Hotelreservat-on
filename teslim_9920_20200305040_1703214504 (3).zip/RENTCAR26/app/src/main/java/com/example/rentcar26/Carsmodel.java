package com.example.rentcar26;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Carsmodel extends AppCompatActivity {

    Button mrc;

    Button opl;

    Button ska;

    public Button ikincisayfa;

    public Button mercedesbilgi;

    public Button fordbilgi;

    public Button skodabilgi;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carsmodel);

        mrc=findViewById(R.id.button);
        mrc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mrc.setText("Car Rented");
            }
        });

        opl=findViewById(R.id.button2);
        opl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opl.setText("Car Rented");
            }
        });

        ska=findViewById(R.id.button3);
        ska.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ska.setText("Car Rented");
            }
        });


        ikincisayfa =findViewById(R.id.next_page);
        mercedesbilgi=findViewById(R.id.mbilgi);
        fordbilgi=findViewById(R.id.fbilgi);
        skodabilgi=findViewById(R.id.sbilgi);

        skodabilgi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bilgi= new Intent(Carsmodel.this,SKODA.class);
                startActivity(bilgi);
            }
        });

        fordbilgi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bilgi= new Intent(Carsmodel.this,FORD.class);
                startActivity(bilgi);
            }
        });

        mercedesbilgi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bilgi = new Intent(Carsmodel.this,mercedes.class);
                startActivity(bilgi);
            }
        });
        ikincisayfa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent next = new Intent(Carsmodel.this, Cars1.class);
                startActivity(next);


            }
        });



            }


}