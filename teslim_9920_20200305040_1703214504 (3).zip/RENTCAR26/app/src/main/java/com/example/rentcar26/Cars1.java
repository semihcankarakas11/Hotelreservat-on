package com.example.rentcar26;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Cars1 extends AppCompatActivity {

    Button add;

    Button update;

    Button sec;

public Button volvobilgi;

public Button opelbilgi;

public Button renaultbilgi;

public Button gerisayfa;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cars1);

        add=findViewById(R.id.button6);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add.setText("Car Rented");
            }
        });

        update=findViewById(R.id.button4);
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update.setText("Car Rented");
            }
        });

        sec=findViewById(R.id.button8);
        sec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sec.setText("Car Rented");
            }
        });


    volvobilgi=findViewById(R.id.Volvobilgi);
    opelbilgi=findViewById(R.id.Opelbilgi);
    renaultbilgi=findViewById(R.id.RenaulBilgi);
    gerisayfa=findViewById(R.id.geri);

    gerisayfa.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent bilgi = new Intent(Cars1.this,Carsmodel.class);
            startActivity(bilgi);
        }
    });




    opelbilgi.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent bilgi = new Intent(Cars1.this,OPEL.class);
            startActivity(bilgi);
        }
    });

    renaultbilgi.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent bilgi = new Intent(Cars1.this,RENAULT.class);
            startActivity(bilgi);

        }
    });

    volvobilgi.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent bilgi = new Intent(Cars1.this,VOLVO.class);
            startActivity(bilgi);
        }
    });
    }
}